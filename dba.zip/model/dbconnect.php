<?php
$conn=oci_connect('bbsystem','bank','localhost/xe') or die (oci_error());

