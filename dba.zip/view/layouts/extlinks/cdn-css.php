<link rel="stylesheet" href="./css/bootstrap.css" />
<link rel="stylesheet" href="./css/fontawesome.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" />
<link rel="stylesheet" href="./css/style.css" />